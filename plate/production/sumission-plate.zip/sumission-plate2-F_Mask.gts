G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.5-8.0.5-0~ubuntu20.04.1*
G04 #@! TF.CreationDate,2024-09-21T23:53:23+02:00*
G04 #@! TF.ProjectId,sumission-plate2,73756d69-7373-4696-9f6e-2d706c617465,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.5-8.0.5-0~ubuntu20.04.1) date 2024-09-21 23:53:23*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H1*
X195959970Y-125713109D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X91184970Y-125713109D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X195959970Y-36019359D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X91184970Y-36019359D03*
G04 #@! TD*
M02*
